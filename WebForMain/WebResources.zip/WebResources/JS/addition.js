﻿//GetForm
function getform(input) {
    var _obj = input.parentNode;
    while (_obj.tagName.toUpperCase() != "FROM") {
        _obj = _obj.parentNode;
    }
}
// Reg
function checkAgree(chk) {
    if (chk.checked) {
        $("#Unnamed3").removeClass("btn_0");
        $("#Unnamed3").addClass("btn_1");
    }
    else {
        $("#Unnamed3").removeClass("btn_1");
        $("#Unnamed3").addClass("btn_0");
    }
}
//ziweipaipan
function checkrealtime(chk)
{
if (chk.checked) {
    $("#ctl00_ContentPlaceHolder1_UpdatePanelb").addClass("show");
    $("#ctl00_ContentPlaceHolder1_UpdatePanelb").removeClass("block");
    }
    else {
    $("#ctl00_ContentPlaceHolder1_UpdatePanelb").removeClass("show");
    $("#ctl00_ContentPlaceHolder1_UpdatePanelb").addClass("block");
    }
}

function qaTypeChanged(drp) {
    if (drp.selectedIndex == 0) {
        $("#info2").addClass("block");
        $("#info2").removeClass("show");
        $("#info1").addClass("block");
        $("#info1").removeClass("show");
    }
    else if (drp.selectedIndex == 1) {
        $("#info1").addClass("show");
        $("#info1").removeClass("block");
        $("#info2").addClass("block");
        $("#info2").removeClass("show");
    }
    else if (drp.selectedIndex == 2) {
        $("#info1").addClass("show");
        $("#info1").removeClass("block");
        $("#info2").addClass("show");
        $("#info2").removeClass("block");
    }
}

function qaCateChanged(drp) {
    if (drp.selectedIndex == 3) {
        document.getElementById("ctl00_ContentPlaceHolder1_drpType").selectedIndex = 0;
        qaTypeChanged(document.getElementById("ctl00_ContentPlaceHolder1_drpType"));
    }
    else if (drp.selectedIndex == 1)
    {
        document.getElementById("ctl00_ContentPlaceHolder1_drpType").selectedIndex = 2;
        qaTypeChanged(document.getElementById("ctl00_ContentPlaceHolder1_drpType"));
    }
    else
    {
        document.getElementById("ctl00_ContentPlaceHolder1_drpType").selectedIndex = 1;
        qaTypeChanged(document.getElementById("ctl00_ContentPlaceHolder1_drpType"));
    }
}

function sansi(input) {
    var gong = input.id.replace("gong", "");
    for (var i = 0; i < 12; i++) {
        if ((i - gong + 12) % 4 == 0 || (i - gong + 12) % 6 == 0) {
            $('#gong' + i).css("background-color", "#ff2a01");
            $('#gong' + i).css("color", "#EEEEEE");
        }
        else {
            $('#gong' + i).css("background-color", "");
            $('#gong' + i).css("color", "#ff2a01");
        }
    }
}
function liusansi(input) {
    var gong = input;
    for (var i = 0; i < 12; i++) {
        if ((i - gong + 12) % 4 == 0 || (i - gong + 12) % 6 == 0) {
            $('#gong' + i).css("background-color", "#ff2a01");
            $('#gong' + i).css("color", "#EEEEEE");

            $('#yun' + i).css("background-color", "#149e11");
            $('#yun' + i).css("color", "#EEEEEE");

            $('#liu' + i).css("background-color", "#005995");
            $('#liu' + i).css("color", "#EEEEEE");
        }
        else {
            $('#gong' + i).css("background-color", "");
            $('#gong' + i).css("color", "#ff2a01");

            $('#yun' + i).css("background-color", "");
            $('#yun' + i).css("color", "#149e11");

            $('#liu' + i).css("background-color", "");
            $('#liu' + i).css("color", "#005995");
        }
    }
}
$(function () {
    $(".login_button").mouseover(function () {
        $(this).css("background-color", "#f7796d")
    }).mouseover(function () {
        $(this).css("background-color", "#A5534C")
    })

})


$(document).ready(function() {
    //paipan
    $(".blocks:even").addClass("even");
    $(".tabs a").click(function() {
        $(this).parent().children("a").removeClass("on");
        $(this).addClass("on");
        idx = $(this).parent().children("a").index(this);
        $(".pp").children(".block").removeClass("show");
        $(".pp").children(".block").eq(idx).addClass("show");
        $("#ctl00_ContentPlaceHolder1_hdType").val((idx + 1) * 10);
        if (idx == 2) {
            $(".stab").addClass("show");
            $(".stab").children("a").removeClass("on");
            $(".stab").children("a").eq(0).addClass("on");
        }
        else {
            $(".stab").removeClass("show");
        }
    });
    $(".stab a").click(function() {
        $(this).parent().children("a").removeClass("on");
        $(this).addClass("on");
        idx = $(this).parent().children("a").index(this);
        $(".pp").children(".block").removeClass("show");
        $(".pp").children(".block").eq(idx + 2).addClass("show");
        $(".stab").addClass("show");
        $("#ctl00_ContentPlaceHolder1_hdType").val(parseInt(parseInt($("#ctl00_ContentPlaceHolder1_hdType").val()) / 10) * 10 + idx + 1);
    })
    var box_taFlag = 0
    $(".box_ta").unbind();
    $(".box_ta").click(function() {
        if ($(this).parent().parent().children(".box_c").css("display") == "block") {
            $(this).css("background-position", "right top");
            $(this).parent().parent().children(".box_c").toggle();
        }
        else {
            $(this).css("background-position", "right bottom");
            $(this).parent().parent().children(".box_c").toggle();
        }
    });
    $(".index_left_new_item span").click(function () {
        $(this).parent().children("span").removeClass("on");
        $(this).addClass("on");
        idx = $(this).parent().children("span").index(this);
        $(this).parent().parent().parent().children(".block").removeClass("show");
        $(this).parent().parent().parent().children(".block").eq(idx).addClass("show")
    });

})
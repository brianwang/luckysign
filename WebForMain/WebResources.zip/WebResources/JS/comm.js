// JavaScript Document
$(document).ready(SetDocument())

function SetDocument() { 
$(".blocks:even").addClass("even");
    $(".tabs a").click(function () {
        $(this).parent().children("a").removeClass("on");
        $(this).addClass("on");
        idx = $(this).parent().children("a").index(this);
        $(this).parent().parent().children(".block").removeClass("show");
        $(this).parent().parent().children(".block").eq(idx).addClass("show")
    });
    $(".stab a").click(function () {
        $(this).parent().children("a").removeClass("on");
        $(this).addClass("on");
        idx = $(this).parent().children("a").index(this);
        $(this).parent().parent().children(".sblock").removeClass("show");
        $(this).parent().parent().children(".sblock").eq(idx).addClass("show")
    })
    var box_taFlag = 0;
    $(".tlk_tt").click(function () {

        if ($(this).parent().parent().attr("class") == "s_tlk2 left") {
            $(this).parent().parent().addClass("s_tlk2s");
            $(this).css("background-position", "right bottom");
        }
        else {
            $(this).parent().parent().removeClass("s_tlk2s");
            $(this).css("background-position", "right top");
        }
    })
    $(".box_ta").unbind();
    $(".box_ta").click(function () {
        if ($(this).parent().parent().children(".box_c").css("display") == "block") {
            $(this).css("background-position", "right top");
            $(this).parent().parent().children(".box_c").toggle();
        }
        else {
            $(this).css("background-position", "right bottom");
            $(this).parent().parent().children(".box_c").toggle();
        }
    })
    //regist
    if ($.formValidator) {
        $.formValidator.initConfig({ formID: "form1", debug: false, submitOnce: true,
            onError: function (msg, obj, errorlist) {
                $("#errorlist").empty();
                $.map(errorlist, function (msg) {
                    $("#errorlist").append("<li>" + msg + "</li>")
                });
                alert(msg);
            },
            submitAfterAjaxPrompt: '有数据正在异步验证，请稍等...'
        });

        $("#ctl00_ContentPlaceHolder1_email").formValidator({ onShow: "", onFocus: "<b><span class='fred'>重要！</span>请填写<span class='fred'>有效邮箱地址</span>，以验证完成注册。</b>", onCorrect: " ", defaultValue: "@" }).inputValidator({ min: 6, max: 100, onError: "邮箱至少<span class='fred'>6</span>个字符,最多<span class='fred'>100</span>个字符" }).regexValidator({ regExp: "^([\\w-.]+)@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.)|(([\\w-]+.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(]?)$", onError: "<span class='err'> </span>你输入的邮箱格式不正确" });
        $("#ctl00_ContentPlaceHolder1_password1").formValidator({ onShow: "", onFocus: "请输入密码,至少<span class='fred'>6</span>位", onCorrect: " " }).inputValidator({ min: 6, empty: { leftEmpty: false, rightEmpty: false, emptyError: "密码两边不能有空格符" }, onError: "密码不能为空或少于6位,请确认" });
        $("#ctl00_ContentPlaceHolder1_password2").formValidator({ onShow: "", onFocus: "输再次输入密码", onCorrect: " " }).inputValidator({ min: 6, empty: { leftEmpty: false, rightEmpty: false, emptyError: "重复密码两边不能有空格符" }, onError: "重复密码不能为空,请确认" }).compareValidator({ desID: "ctl00_ContentPlaceHolder1_password1", operateor: "=", onError: "2次密码不一致,请确认" });
        $("#ctl00_ContentPlaceHolder1_name").formValidator({ onShow: "", onFocus: "请输入您在上上签的通用名,最多<span class='fred'>10</span>个字", onCorrect: " " }).inputValidator({ min: 1, max: 10, onError: "名号不能为空且最多10个字符,请确认" });
        $("#ctl00_ContentPlaceHolder1_code").formValidator({ onShow: "", onFocus: "请输入上面图片中的文字", onCorrect: " " }).inputValidator({ min: 4, max: 4, onError: "验证码输入有误,请确认" });
    }
    //regist end
}